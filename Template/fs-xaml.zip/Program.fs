﻿// Learn more about F# at http://fsharp.org
// See the 'F# Tutorial' project for more help.

open MainWindow

open System

[<STAThread>]
MainWindow.run()